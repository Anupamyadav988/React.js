import React from "react";
import ReactDOM from "react-dom";
const fName = "Anupam";
const lName = "Yadav";
const num = 4;
ReactDOM.render(
  <div>
    <h1>Hello {fName + " " + lName}!</h1>
    {/* <h1>HEllo {fName} {lname}! </h1> */}
    <p>Your lucky number is {num} </p>
    {/* <p> your lucky number is {3+4}</p> */}
  </div>,
  document.getElementById("root")
);
